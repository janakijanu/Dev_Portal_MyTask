// Component for Home page
class Mashup extends React.Component {
    render() {
      return (
        <div> 
       
          <div className="menu">
            <div className="container-fluid">
		          <div className="navbar-header">
                <ul className="nav navbar-nav navbar-left">
                  <li><img src="./images/image3.png" alt="image3"></img></li>
		              <li><h3>APIC - EM</h3></li>
                </ul>
		          </div>
		          <div>
			          <ul className="nav navbar-nav navbar-right">
				          <li><a href="#"MashupMashup ><span className="glyphicon glyphicon-search"></span>&nbsp;&nbsp;&nbsp;&nbsp;Contact</a></li>
			          	<li><a href="#"><span className="glyphicon glyphicon-remove-circle"></span>&nbsp;&nbsp;&nbsp;&nbsp;Close</a></li>
			          </ul>
		          </div>
	          </div>
            
          </div> 
        </div>


      )
    }
  }