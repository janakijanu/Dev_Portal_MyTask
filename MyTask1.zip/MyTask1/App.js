import React, { Component } from 'react';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css'
import './App.css'


class App extends React.Component{
  render(){
  return <div>
                
      </div>  
  }
} 
export default App;
