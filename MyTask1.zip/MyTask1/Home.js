import React, { Component } from 'react';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom'
import Header from './Header';

class Home extends React.Component {
    render() {
      return <div className='Modal'>
                <Header></Header>
                <Login />
                <Reference/>
             </div>
    }
  }
  
  class Login extends React.Component {
    constructor(){
      super()
    this.handleClick = this.handleClick.bind(this);
     }
     handleClick(){
       alert ("hi");
    }
    render() {
      return <div className='logging'>
                <Logo />
                <form>
                  <img className="logoimage" src="./images/image1.jpg" alt="image1"></img>  
                  <h4 className="apptype"> Application Type</h4>
                </form>
                <div className="colorCss">
                  <div className='social-signin'>
                  <Link to='/Mashup'>
                    <button className="mp">Mashup</button>
                  </Link>
                  <Link to='/NonMashup'>
                    <button className="ump">Non-Mashup</button>
                    </Link>
                  </div>  
                  <h4 className="apptype"> Develope new App</h4>
                </div>                
             </div>
    }
  }
  
  // logo
  class Logo extends React.Component {
    render() {
      return <div className="logo">
                  <i className="fa fa-bug" aria-hidden="true"></i> 
                  <span> CISCO </span>
                </div>
    }
  }
  
  class Reference extends React.Component {
    render() {
      return <div className='ref'>
                <Logo1 />
                <form>
                  <img className="logoimage" src="./images/image2.jpg" alt="image2" ></img>
                  <h4 className="apptype"> Builton</h4>
                </form>
                <div className="colorCss">
                  <div className='social-signin'>
                    <Link to='/Application'>
                      <button className="mp">Application1</button>
                    </Link>
                    <button className="ump">Application2</button>
                  </div>                    
                  <h4 className="apptype"> Open Existing App</h4>
                </div>
             </div>
    }
  }
  
  // logo
  class Logo1 extends React.Component {
    render() {
      return <div className="logo">
                  <i className="fa fa-bug" aria-hidden="true"></i> 
                  <span> Reference </span>
                </div>
    }
  }

  export default Home;