import React, { Component } from 'react';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom';

// Component for Home page
class Header extends React.Component {
    render() {
      return (
        <div> 
       
          <div className="menu">
            <div className="container-fluid">
		          <div className="navbar-header">
                <ul className="nav navbar-nav navbar-left">
                  <li><img src="./images/image3.png" alt="image3"></img></li>
		              <li><h3>APIC - EM</h3></li>
                </ul>
		          </div>
		          <div className="icons">
			          <ul className="">
				          <li><a href="#"MashupMashup><span className="glyphicon glyphicon-search"></span>&nbsp;&nbsp;&nbsp;&nbsp;Contact</a></li>
                  <Link to='/'>
			          	<li className=""><a href="#" className=""><span className="glyphicon glyphicon-remove-circle"></span>&nbsp;&nbsp;&nbsp;&nbsp;Close</a></li></Link>
			          </ul>
		          </div>
	          </div>
            
          </div> 
        </div>


      )
    }
  }

  export default Header;