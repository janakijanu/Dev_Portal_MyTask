import React, { Component } from 'react';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom'
import Header from './Header';

 // Component for Home page
 class NonMashup extends React.Component {
    render() {
      return (
        <div>
          <Header></Header>
          <div className='container'>
            <div className='row'>
              <div className='col-md-10 push-md-1 col-lg-8 push-lg-2 text-center developmentSite'>
                <h1 className="alignCss"><b>Development Site</b></h1>
                <p className="alignCss">Cannot Process.Try it through Mashup.</p>
              </div>
            </div>
          </div>
        </div>
      );
    }
  }

export default NonMashup;