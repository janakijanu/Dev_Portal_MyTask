import React, { Component } from 'react';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom';

// Component for Home page
class Header1 extends React.Component {
    render() {
      return (
        <div> 
       
          <div className="menu">
            <div className="container-fluid">
		          <div className="navbar-header">
                <ul className="nav navbar-nav navbar-left">
                  <li><img src="./images/image3.png" alt="image3"></img></li>
		              <li><h3 class="applicationsite">Angular2 Atlantic UI Component Library<span className="para14">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Getting Started</span></h3></li>
                </ul>
		          </div>
		          <div className="icons1">
			          <ul className="">
                  <Link to='/'>
			          	<li><a href="#"><span className="glyphicon glyphicon-remove-circle"></span>&nbsp;&nbsp;&nbsp;&nbsp;Close</a></li></Link>
			          </ul>
		          </div>
	          </div>
            
          </div> 
        </div>


      )
    }
  }

  export default Header1;