import React, { Component } from 'react';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom';
import Header from './Header';
import Home from './Home.js'
// import { MDBContainer, MDBStepper, MDBStep, MDBIcon } from "mdbreact";
//import "mdbreact/dist/css/mdb.css";


// const HelloStyle = styledComponents.div`
//   color: red;
// `;

const steps = [
  {
    label: 'Download',
    component: <div className="container defHeight">
                <div className="row">
                  <div className="col-md-12 col-sm-12 col-lg-12 Step1">
                    Download Node.js and APIC-EM running Cluster IP
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-4 col-sm-4 col-lg-4">
                    <img className="logoimage1 image2" src="./images/image1.png" alt="image1"></img>
                  </div>
                  <div className="col-md-4 col-sm-4 col-lg-4">
                    <img className="logoimage1 image2" src="./images/image5.jpg" alt="image1"></img>
                  </div>
                  <div className="col-md-4 col-sm-4 col-lg-4">
                    <img className="logoimage1 image2" src="./images/image6.jpeg" alt="image1"></img>
                  </div>
                </div>
              </div>,
    exitValidation: false
  },
  {
    label: 'App Builder',
    component: <div className="container defHeight">
                <div className="">
                  <div className="row">
                    <div className="col-lg-12 col-sm-12 col-md-12">
                      <p className="para1">Generate all boilerplate code for a new application within <b>30 seconds!</b></p>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-lg-12 col-sm-12 col-md-12">
                      <p className="para1">Generate all boilerplate code for a new application within <b>30 seconds!</b></p>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-lg-12 col-sm-12 col-md-12">
                      <p className="para1">Generate all boilerplate code for a new application within <b>30 seconds!</b></p>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-lg-12 col-sm-12 col-md-12">
                      <p className="para1">Generate all boilerplate code for a new application within <b>30 seconds!</b></p>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-lg-12 col-sm-12 col-md-12">
                      <p className="para2">We will generate recommended app skeleton with all key platform capabilities including In-built security, an access to rich set of widgets, utilities and components</p>
                    </div>
                  </div>
                </div>
                <div className="row second">
                  <div className="col-lg-5 col-sm-5 col-md-5">
                    <img className="logoimage1  second-image" src="./images/image7.png" alt="image1"></img>
                  </div>
                  <div class="col-lg-2 col-sm-2 col-md-2" offset="2"></div>
                  <div className="col-lg-5 col-sm-5 col-md-5">
                    <p className="para3">Enter Application Name</p>
                    <hr className="name-application"/>
                    <button className="button1">Create</button>
                    <img className="image1" src="./images/image9.jpeg" alt="image1"></img>
                  </div>
                </div>
              </div>
  },
  {
    label: 'Platform UI Repository',
    component: <div className="container defHeight">
                <div className="row">
                  <div className="col-lg-12 col-sm-12 col-md-12">
                    <p className="para4">Checkout Platform-UI Code</p>
                  </div>
                </div>
                <div className="row">
                  <div className="col-lg-12 col-sm-12 col-md-12">
                    <p className="para5">Checkout Platform-UI Code and repository. Make apic -em-platform-ui/ui/ as your working directory</p>
                  </div>
                </div>
                <div className="row third-row">
                  <div className="col-lg-3 col-sm-3 col-md-3">
                    <img className="logoimage1 image3" src="./images/image8.png" alt="image1"></img>
                  </div>
                  <div className="col-lg-9 col-sm-9 col-md-9">
                    <h4 className="code1">git clone -b staging ssh://wwwin-git-sjc.cisco.com/git/eng_sdn/apic-em-platform-ui</h4>
                  </div>
                </div>
              </div>
  },
  {
    label: 'Update Meta',
    component: <div className="container defHeight">
                <div className="row">
                  <div className="col-lg-12 col-sm-12 col-md-12">
                    <p className="para6">Point your app location and to point your UI to the APIC-EM cluster of your choice</p>
                  </div>
                </div>
                <div className="row">
                  <div className="col-lg-12 col-sm-12 col-md-12">
                    <p className="para7">To load your app: Modify plugin section of <b>path to location/apic-em-platform-ui/ui/source/config.json</b></p>
                  </div>
                </div>
                <div className="row fourth-row">
                  <div className="col-lg-3 col-sm-3 col-md-3">
                    <img className="logoimage1 image3" src="./images/image8.png" alt="image1"></img>
                  </div>
                  <div className="col-lg-9 col-sm-9 col-md-9">
                    <h4 className="code1">"plugins":["path to your application - the same path where you ran the App Builder"]
                      "host":"https://apic-em-cluster-ip"
                    </h4>
                  </div>
                </div>
              </div>
  },
  {
    label: 'Runscripts',
    component: <div className="container defHeight">
                <div className="row">
                  <div className="col-lg-12 col-sm-12 col-md-12">
                    <p className="para8">Point your app location and to point your UI to the APIC-EM cluster of your choice</p>
                  </div>
                </div>
                <div className="row">
                  <div className="col-lg-12 col-sm-12 col-md-12">
                    <p className="para9">one time development env setup - This will perform the installing of required libraries via NPM for the backend and frontend.</p>
                  </div>
                </div>
                <div className="row fifth-row">
                  <div className="col-lg-3 col-sm-3 col-md-3">
                    <img className="logoimage1 image3" src="./images/image8.png" alt="image1"></img>
                  </div>
                  <div className="col-lg-9 col-sm-9 col-md-9">
                    <h4 className="code1">sudo ./dev-env-setup<br/>./dev-start
                    </h4>
                  </div>
                </div>
              </div>
  }
]

class Mashup extends React.Component {
  constructor() {
    super();
    
    this.state = { activeStep: 0};
  }
  
  
  handleStepChange(activeStep) {
    this.setState({ activeStep });
  }
  
  nextStep () {
    if (this.state.activeStep < this.props.steps.length - 1) {
      console.log("steps:"+this.state.activeStep);
      this.setState({ activeStep: this.state.activeStep + 1 });    
    }
  }
  
  previousStep() {
    if (this.state.activeStep > 0) {
      this.setState({ activeStep: this.state.activeStep - 1 });    
    }
  }
  
  render() {
    const { steps, onFinish } = this.props;
    const { activeStep } = this.state;
    const stepIndicators = steps.map((step, i) => {
      function span(i){
        if(i == 4 ){
          console.log("no");
         // debugger;
          return <span className="no-steps">{i + 1}</span>
        }
        else{
          console.log("yes");
          return <span>{i + 1}</span>
        }
      }
      return (
        <div className="stepper-inner">
          <div className={`stepper-number ${activeStep === i && 'active'} ${activeStep > i && 'completed'}`}>
            {span(i)}
            <div className="line-linkage"></div>
          </div>

          {i !== steps.length && <div className="stepper-label">{step.label}</div>}
        </div>
       );
    });
    
    return (
      <div>
        <Header></Header>
        <div>
	        <ul className="home">
		        <li><span className="glyphicon glyphicon-home home-page"></span>&nbsp;&nbsp;|&nbsp;&nbsp;APP BUILDER - MASHUP</li>
	        </ul>
        </div>
        <div className="stepper">
          <div className="stepper-indicator">
            {stepIndicators}
          </div>
          <hr className="horizontalLine"></hr>
          <div className="stepper-steps">
            {steps[activeStep].component}
          </div>
          <div>
            </div>
          </div>
          <div className="stepper-actions">
            <button onClick={() => this.previousStep()}>Previous</button>
            {activeStep === steps.length - 1 ?
              <Link to='/'>
              <button disabled={!!steps[activeStep].exitValidation} onClick={onFinish}>Submit</button> </Link>: 
              <button className="" disabled={!!steps[activeStep].exitValidation} onClick={() => this.nextStep()}>Next</button>}
          </div>
        </div>
    )
  }
}

const App = (props) => {
  const submit = () => {
  }
  
  return (
    <Mashup steps={steps} onFinish={submit} />
  );
}



 

export default App;