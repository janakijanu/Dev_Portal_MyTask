
import React from 'react';
import ReactDOM from 'react-dom';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom'
import App from './App.js';
import Home from  './Home.js';
import Mashup from  './Mashup.js';
import NonMashup from  './NonMashup.js';
import history from './history.js'
import Application from './Application.js';
//import Header from './Header';

const routing = (
    <Router history={history}>
      <div className="overflowHidden">
        <Route exact path="/" component={Home} />
        <Route path="/Mashup" component={Mashup} />
        {/* <Route path="/Header" component={Header} /> */}
        <Route path="/NonMashup" component={NonMashup} />
        <Route path="/Application" component={Application} />
      </div>
    </Router>
  )

ReactDOM.render(routing, document.getElementById('rootUI'));
