import React, { Component } from 'react';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom'
import Header1 from './Header1.js';

class Application extends React.Component {
    render() {
      return (
        <div>
          <Header1></Header1>
          <div className=''>
            <div className='row'>
              <div className='col-md-10 push-md-1 col-lg-8 push-lg-2 text-center developmentSite1'>
                <div className="borderCss">
                  <div className="topCss">
                    <h1 className="app1">Angular2 Atlantic UI Component Library</h1>
                  </div>
                  <button className="buttonBorder">Download Angular2 Atlantic UI Library</button>
                  <button className="buttonBorder1">Explore Angular2 Atlantic UI Library</button>
                  <p class="para11">Version 1.0.1</p>
                </div>
                <p class="para12">Welcome to Angular2 Atlantic UI Component Library</p>
              </div>
            </div>
          </div>
        </div>
      );
    }
  }

  export default Application;

